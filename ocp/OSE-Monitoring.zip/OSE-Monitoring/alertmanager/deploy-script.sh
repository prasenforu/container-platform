#!/bin/sh

# Deployment script

NAMESPACE=${NAMESPACE:-prometheus}
KUBECTL="oc ${KUBECTL_PARAMS} --namespace=\"${NAMESPACE}\""

for yml in *.yml; do
  eval "${KUBECTL} create -f \"${yml}\""
done
